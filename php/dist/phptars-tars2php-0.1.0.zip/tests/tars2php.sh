#!/usr/bin/env bash

php ../src/tars2php.php tarsclient.proto.php

php ../src/tars2php.php tars.proto.php
